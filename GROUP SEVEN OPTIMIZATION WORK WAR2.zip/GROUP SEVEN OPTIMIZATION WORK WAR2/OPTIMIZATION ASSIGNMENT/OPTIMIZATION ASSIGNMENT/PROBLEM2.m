%Problem 2: Minimum cost pumping schedule.
% x(1) = Period 1 volume; x(2) = Period 2 volume(m^3)
clear;
clc;
nvar = 2;
%Objective: Minimize C = 80*x1 + 120*x2
objective = @(x) 80*x(1) + 120*x(2);
%Inequalities: x1 < 700, x2 <= 600
A = [1 0; 0 1];
b = [700; 600];
Aeq = [1 1];
beq = 1000;
Ib = [0; 0];
ub = [700; 600];
[x, fval] = ga(objective, nvar, A, b,Aeq, beq, Ib, ub, []);
%Results
fprintf('Period 1 pumping: %.2f m^3\n', x(1));
fprintf('Period 2 pumping: %.2f m^3\n', x(2));
fprintf('Minimum pumping cost: UGX%.2f\n', fval);