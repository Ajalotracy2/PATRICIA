% Problem 3: Reservoir allocation; x in 1000m^3
clear;
clc;
% variables; x(1) = Municipal, x(2) = Irrigation, x(3) = Industry
objective = @(x) -(500*x(1) + 300*x(2) + 400*x(3));
nvar = 3;
% Linear inequality: x1 + x2 + x3 <=100
A = [1 1 1];
b = 100;
Aeq = [];
beq = [];
Ib = [20; 30; 10];
ub = [40; 60; 30];

%General Function
[x, fval] = ga(objective, nvar, A, b, Aeq, beq, Ib, ub, []);
% Results
fprintf('Municipal: %.2f\n', x(1));
fprintf('Irrigation: %.2f\n', x(2));
fprintf('Industry: %.2f\n', x(3));
fprintf('Maximum benefit: %.2f thousand UGX\n', -fval);