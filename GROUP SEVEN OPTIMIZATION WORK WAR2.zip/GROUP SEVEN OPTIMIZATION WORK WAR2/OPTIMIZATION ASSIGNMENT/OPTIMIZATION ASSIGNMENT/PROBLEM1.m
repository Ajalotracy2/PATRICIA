% Problem 1: Irrigation crop-area optimization
% x(1) = maize hectares; x(2) = vegetable hectares.
clear;
clc;
nvar = 2;
% Maximize Z = 1200000*x(1) + 2000000*x(2);
objective = @(x) -(1200000*x(1) + 2000000*x(2));
% Linear Inequalities.
% x1 + x2 <= 50
% 3000*x(1) + 5000*x(2) <= 120000
A = [1 1; 3000 5000];
b = [50; 120000];
Aeq = [];
beq = [];
Ib = [10; 0];
ub = [Inf; 20];
[x, fval] = ga(objective, nvar, A, b, Aeq, beq, Ib, ub, []);
%Results
fprintf('Maize area: %.2f ha\n', x(1));
fprintf('Vegetable area: %.2f ha\n', x(2));
fprintf('Maximum net return: UGX%.2f ha\n', -fval);
fprintf('Water used: %.2f m^3\n', 3000*x(1) + 5000*x(2));